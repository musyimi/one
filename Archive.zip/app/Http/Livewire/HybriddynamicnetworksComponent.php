<?php

namespace App\Http\Livewire;

use Livewire\Component;

class HybriddynamicnetworksComponent extends Component
{
    public function render()
    {
        return view('livewire.hybriddynamicnetworks-component')->extends('base');
    }
}
