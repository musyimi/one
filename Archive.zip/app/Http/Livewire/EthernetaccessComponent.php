<?php

namespace App\Http\Livewire;

use Livewire\Component;

class EthernetaccessComponent extends Component
{
    public function render()
    {
        return view('livewire.ethernetaccess-component')->extends('base');
    }
}
