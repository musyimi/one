<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ExperienceComponent extends Component
{
    public function render()
    {
        return view('livewire.experience-component')->extends('base');
    }
}
