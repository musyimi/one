<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DedicatedcloudconnectionComponent extends Component
{
    public function render()
    {
        return view('livewire.dedicatedcloudconnection-component')->extends('base');
    }
}
