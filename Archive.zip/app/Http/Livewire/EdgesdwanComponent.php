<?php

namespace App\Http\Livewire;

use Livewire\Component;

class EdgesdwanComponent extends Component
{
    public function render()
    {
        return view('livewire.edgesdwan-component')->extends('base');
    }
}
