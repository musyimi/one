<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DedicatedinternetaccessComponent extends Component
{
    public function render()
    {
        return view('livewire.dedicatedinternetaccess-component')->extends('base');
    }
}
