<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CustomerpremisesequipmentComponent extends Component
{
    public function render()
    {
        return view('livewire.customerpremisesequipment-component')->extends('base');
    }
}
