<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SecurenetComponent extends Component
{
    public function render()
    {
        return view('livewire.securenet-component')->extends('base');
    }
}
