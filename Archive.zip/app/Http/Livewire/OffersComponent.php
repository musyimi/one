<?php

namespace App\Http\Livewire;

use Livewire\Component;

class OffersComponent extends Component
{
    public function render()
    {
        return view('livewire.offers-component')->extends('base');
    }
}
