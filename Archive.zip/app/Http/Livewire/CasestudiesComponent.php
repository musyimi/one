<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CasestudiesComponent extends Component
{
    public function render()
    {
        return view('livewire.casestudies-component')->extends('base');
    }
}
