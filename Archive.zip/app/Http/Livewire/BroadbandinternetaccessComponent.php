<?php

namespace App\Http\Livewire;

use Livewire\Component;

class BroadbandinternetaccessComponent extends Component
{
    public function render()
    {
        return view('livewire.broadbandinternetaccess-component')->extends('base');
    }
}
