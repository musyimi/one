<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AskforfibreComponent extends Component
{
    public function render()
    {
        return view('livewire.askforfibre-component')->extends('base');
    }
}
