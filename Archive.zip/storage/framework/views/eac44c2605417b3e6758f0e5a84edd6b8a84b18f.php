  <div>
      <div class="home-fibre">

        <img src="<?php echo e(URL::asset('asset/smart.jpg')); ?>" alt="" />
        <div>
          <div>
            <h1>5G/Private LTE</h1>
            <p>
              LTE and 5G Wireless Edge Solutions for every network. To get
              started, choose your experience
            </p>
          </div>
        </div>
      </div>
    </div>

    <section>
      <div class="private">
        <p>Private LTE</p>
      </div>
      <div class="private1">
        <p>
          In large areas where organizations have essential connected devices
          and applications, wireless connectivity is a challenge. Wi-Fi isn’t
          secure enough and doesn’t scale well, but public LTE might not provide
          the dedicated bandwidth or cost-effectiveness you need. Private
          Cellular Networks, including Private LTE (PLTE), have emerged as the
          best option for wireless networking in sprawling spaces ranging from
          campuses, shipping ports, and refineries to Smart Cities. In these
          “wide-area LAN” scenarios, Private LTE combines the control and fixed
          costs of a private network with the flexibility, security, and
          macro-network benefits of cellular broadband — with a built-in pathway
          to Private 5G.
        </p>
      </div>
    </section>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/fivegprivatelte-component.blade.php ENDPATH**/ ?>