<div>
    edge page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/edgesdwan-component.blade.php ENDPATH**/ ?>