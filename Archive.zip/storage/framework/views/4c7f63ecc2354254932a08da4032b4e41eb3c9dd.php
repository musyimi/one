<div>
    ethernet page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/ethernetaccess-component.blade.php ENDPATH**/ ?>