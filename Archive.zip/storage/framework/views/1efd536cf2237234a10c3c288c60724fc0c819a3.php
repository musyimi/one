<div class="offers">
        <img src="<?php echo e(URL::asset('asset/offers.jpg')); ?>" alt="" />
        <div class="offer1">
          <h1>Get crazy offers</h1>
          <p>
            Introduce 10 neighbours to smart home fibre and get a lifetime
            internet access
          </p>
        </div>
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/offers-component.blade.php ENDPATH**/ ?>