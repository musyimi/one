    <div>
      <div class="home-fibre">

        <img src="<?php echo e(URL::asset('asset/satelite.jpg')); ?>" alt="" />
        <div>
          <div>
            <h1>Entertainment galore</h1>
            <p>
              Stay connected to your friends and family, catch up on your latest
              e-mails or listen to your favourite playlists and blockbuster
              movies.
            </p>
          </div>
        </div>
      </div>
    </div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/entertainment-component.blade.php ENDPATH**/ ?>