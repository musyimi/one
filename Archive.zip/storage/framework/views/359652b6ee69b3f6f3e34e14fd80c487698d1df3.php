<div>
    customer premises page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/customerpremisesequipment-component.blade.php ENDPATH**/ ?>