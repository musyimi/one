  <div class="Case">
      <img src="<?php echo e(URL::asset('asset/case.jpg')); ?>" alt="" />
    </div>

    <div>
      <div class="case-content">
        <p>
          A food company with worldwide presence simplified its complex
          telecommunications infrastructure with the help of Cato networks
        </p>
        <img src="<?php echo e(URL::asset('asset/case1.jpg')); ?>" alt="" />
      </div>
      <div class="case-content">
        <img src="<?php echo e(URL::asset('asset/case2.jpg')); ?>" alt="" />
        <p>
          An airline required redundant internet access to operate without
          interruptions across different airports. Cato networks was able to
          deliver
        </p>
      </div>
      <div class="case-content">
        <p>
          Wind farms are located in remote and hard to access locations. Cato
          Networks was able to bring solutions to this renewable energy company
        </p>
        <img src="<?php echo e(URL::asset('asset/case3.jpg')); ?>" alt="" />
      </div>
      <div class="case-content">
        <img src="<?php echo e(URL::asset('asset/case4.jpg')); ?>" alt="" />
        <p>
          Cato networks helped Kenyan government bring justice courts to
          isolated regions of the country that had limited infrastructure
        </p>
      </div>
    </div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/casestudies-component.blade.php ENDPATH**/ ?>