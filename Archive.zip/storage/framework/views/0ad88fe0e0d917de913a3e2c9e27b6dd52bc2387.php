<div>
    hybrid page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/hybriddynamicnetworks-component.blade.php ENDPATH**/ ?>