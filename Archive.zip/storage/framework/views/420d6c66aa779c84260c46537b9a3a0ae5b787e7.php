
  <section>
      <div class="smart">
        <div>
          <ul class="smart1">


            <li><a href="/askforfibre"> Ask for fibre</a></li>
            <li>Coverage</li>
            <li><a href="/offers"> Offers</a></li>
            <li>Get in touch</li>
            <li>Faq's</li>
          </ul>
        </div>
        <div>
          <ul class="smart2">
            <li><i class="fab fa-facebook fa-2x"></i></li>
            <li><i class="fab fa-twitter"></i></li>
            <li><i class="fab fa-instagram"></i></li>
            <li><i class="fab fa-youtube"></i></li>
          </ul>
        </div>
      </div>
    </section>

    <section>
      <div class="smart-container">
        <ul class="smart3">
          <li>

            <span><i class="fas fa-home"></i></span>
            <a href="/homefibre">  Home fibre</a>

          </li>
          <li>
            <span><i class="fas fa-shield-alt"></i></span>
            <a href="/securenet">  SECURE NET</a>

          </li>
          <li>
            <span><i class="fas fa-wifi"></i></span>
             <a href="/fiveglte">   5G/Private LTE</a>

          </li>
          <li>
            <span><i class="fas fa-tv"></i></span>
            <a href="/entertainment">  ENTERTAINMENT</a>

          </li>
          <li>
            <span><i class="fas fa-binoculars"></i></span>
             <a href="/homecctv">     HOME CCTV</a>

          </li>
          <li>
            <span><i class="fas fa-hdd"></i></span>
               <a href="/iotworld">     IOT world</a>

          </li>
        </ul>
      </div>
    </section>

    <section>
      <div class="smart-content">
        <img src="<?php echo e(URL::asset('asset/catoimage.jpeg')); ?>" alt="" />
        <h1>Enjoy every moment with Cato smart home access</h1>
      </div>
    </section>

    <section>
      <div class="smart-content1">
        <h1>Access limitless possibilities from the comfort of your home</h1>
      </div>
    </section>
    <section>
      <div>
        <ul class="smart-content2">
          <li>Entertainment</li>
          <li>Gaming</li>
          <li>Learning</li>
          <li>Safety</li>
        </ul>
      </div>
    </section>

<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/smartfibre-component.blade.php ENDPATH**/ ?>