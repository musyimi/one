  <div class="experience">

      <img src=" <?php echo e(URL::asset('asset/experience.jpg')); ?>" alt="" />
    </div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/experience-component.blade.php ENDPATH**/ ?>