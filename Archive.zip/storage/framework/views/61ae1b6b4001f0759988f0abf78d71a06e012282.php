<div>
    wildix page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/wildix-component.blade.php ENDPATH**/ ?>