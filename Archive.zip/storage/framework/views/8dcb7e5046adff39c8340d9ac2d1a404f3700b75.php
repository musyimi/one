    <div>
      <div class="home-fibre">

        <img src="<?php echo e(URL::asset('asset/iot2.jpg')); ?>" alt="" />
        <div>
          <div>
            <h1>Cato secure IOT</h1>
            <p>
              Home automation gives you access to control devices in your home
              from a mobile device anywhere in the world. The term may be used
              for isolated programmable devices, like thermostats and sprinkler
              systems, but home automation more accurately describes homes in
              which nearly everything — lights, appliances, electrical outlets,
              heating and cooling systems — are hooked up to a remotely
              controllable network.
            </p>
          </div>
        </div>
      </div>
    </div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/iotworld-component.blade.php ENDPATH**/ ?>