<div>
broadband page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/broadbandinternetaccess-component.blade.php ENDPATH**/ ?>