<div>
      <div class="home-fibre">

        <img src="<?php echo e(URL::asset('asset/smart.jpeg')); ?>" alt="" />
        <div>
          <div>
            <h1>Tuko tayari na Cato smart home Fibre</h1>
            <p>An amazing experience awaits you right at home.</p>
          </div>
        </div>
      </div>
    </div>

    <section>
      <div class="home-fibre1">
        <p>Home Fibre packages</p>
      </div>
      <div class="packages">
        <div class="home-package">
          <div class="package1">
            <p>Bronze</p>
          </div>
          <div>
            <span class="package2">10 mbps</span>
            <ul>
              <li>Fast web browsing</li>
              <li>Movies & music streaming</li>
              <li>Live tv</li>
              <li>Multi device streaming</li>
              <li>Home automation</li>
              <li>Home automation</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 2,650</li>
              <li>for 30 days</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Silver</p>
          </div>
          <div>
            <span class="package2">25 mbps</span>
            <ul>
              <li>Fast web browsing</li>
              <li>Movies & music streaming</li>
              <li>Live tv</li>
              <li>Multi device streaming</li>
              <li>Home automation</li>
              <li>Home automation</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 4,500</li>
              <li>for 30 days</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Gold</p>
          </div>
          <div>
            <span class="package2">45 mbps</span>
            <ul>
              <li>Fast web browsing</li>
              <li>Movies & music streaming</li>
              <li>Live tv</li>
              <li>Multi device streaming</li>
              <li>Home automation</li>
              <li>Home automation</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 11,500</li>
              <li>for 30 days</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Saphirre</p>
          </div>
          <div>
            <span class="package2">100 mbps</span>
            <ul>
              <li>Fast web browsing</li>
              <li>Movies & music streaming</li>
              <li>Live tv</li>
              <li>Multi device streaming</li>
              <li>Home automation</li>
              <li>Home automation</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 25,000</li>
              <li>for 30 days</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/homefibre-component.blade.php ENDPATH**/ ?>