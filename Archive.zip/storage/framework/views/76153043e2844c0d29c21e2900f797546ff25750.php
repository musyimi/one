<div>
   dedicated internet access page
</div>
<?php /**PATH /Users/repaircentre/Desktop/two/resources/views/livewire/dedicatedinternetaccess-component.blade.php ENDPATH**/ ?>