<div>
    dedicated cloud page
</div>
