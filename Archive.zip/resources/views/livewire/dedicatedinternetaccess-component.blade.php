<div>
   dedicated internet access page
</div>
