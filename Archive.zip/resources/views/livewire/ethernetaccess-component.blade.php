<div>
    ethernet page
</div>
