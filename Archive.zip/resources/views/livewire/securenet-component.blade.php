  <div>
      <div class="home-fibre">

        <img src="{{URL::asset('asset/security.jpg')}}" alt="" />
        <div>
          <div>
            <h1>Cato secure net</h1>
            <p>
              Complete protection of personal data and parental control/manage
              your child's internet usage
            </p>
          </div>
        </div>
      </div>
    </div>

    <section>
      <div class="home-fibre1">
        <p>Get ready for whatever's next</p>
      </div>
      <div class="packages">
        <div class="home-package">
          <div class="package1">
            <p>Essential</p>
          </div>
          <div>
            <ul>
              <li>Protection against viruses</li>
              <li>Movies & music streaming</li>
              <li>Wi-Fi protection against hackers</li>
              <li>Virus scan for external devices</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 6,600/year</li>
              <li>Kshs 650/month</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Advanced</p>
          </div>
          <div>
            <span class="package2">25 mbps</span>
            <ul>
              <li>Protection against viruses and advanced threats</li>
              <li>Personal data protection</li>
              <li>Parental control: manage your child’s internet use</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 9,000/year</li>
              <li>fKshs 800/month</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Complete</p>
          </div>
          <div>
            <ul>
              <li>
                Protection against viruses, advanced threats and cyberattacks
              </li>
              <li>Complete protection of personal data and passwords</li>
              <li>PC optimizer and tuneup</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 10,000/year</li>
              <li>Kshs 1,200/month</li>
            </ul>
          </div>
        </div>
        <div class="home-package">
          <div class="package1">
            <p>Premium</p>
          </div>
          <div>
            <ul>
              <li>Protection against viruses</li>
              <li>Wi-Fi protection against hackers</li>
              <li>Virus scan for external devices</li>
            </ul>
          </div>
          <div class="package3">
            <ul>
              <li>Kshs 15,000/year</li>
              <li>Kshs 1,500/month</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
