<div class="about">

      <img src="{{URL::asset('asset/aboutus.jpg')}}" alt="" />
      <p>
        We are a pioneer digital champion, always been focused on innovation and
        evolution, thinking about future to make it, to stay ahead as a truly
        meaningful and purposeful organization. We offer variety of ICT
        solutions and digital services in several categories including
        telecommunication, IT, financial technology, digital media,
        cybersecurity, and other advanced digital solutions, with that we are
        leading the digital transformation nationally and regionally.
      </p>
</div>
