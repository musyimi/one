<div>
    customer premises page
</div>
